<!DOCTYPE html>
<html>
<head>
<title>SL Translation Services</title>
<style>
body {
  background-color: #F5EEF8;
}
h1 {
  font-family: Century Gothic;
  font-size: 20px;
  color: #B724F7 ;
  font-style:italic;
}
h2 {
  font-family: Century Gothic;
  font-size: 17px;
  color: #D478FB;
  font-style:italic;
}
p {
  font-family: Century Gothic;
  font-size: 15px;
  color: #000000;
}

</style>
</head>
<body>
<h1>Welcome to SL Language Services!</h1>
<h2>EN/FR>ES Translator, ES Proofreader, and other linguistic services<br>
Translation & Interpreting Project Manager</h2>
<p>Welcome to our HTML page!</p>
<p>We provide English and French into Spanish translation, localization, and transcreation services.<br>
We also offer Spanish proofreading and copywriting services.<br>
In addition, we offer English, French, Spanish, and Italian transcription services.<br>
Finally, we provide Translation & Interpreting Project Management Services</p>
<p>Contact us at <a href="mailto:Sonia.Lopez@etu.unige.ch">E-mail</a>.</p>
<p style="color:#A569BD;font-style:italic;font-weight:bold; font-size:13px;">We look forward to hearing from you!</p>
</body>
</html>
